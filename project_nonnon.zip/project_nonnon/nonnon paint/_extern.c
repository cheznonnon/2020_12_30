// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [!] : gcc4 : don't use "extern" for global "static" variables




// Key Bindings

#define N_PAINT_KEY_A 'A'
#define N_PAINT_KEY_B 'B'
#define N_PAINT_KEY_C 'C'
#define N_PAINT_KEY_D 'D'
#define N_PAINT_KEY_E 'E'

#define N_PAINT_KEY_J 'J'

#define N_PAINT_KEY_1 '1'
#define N_PAINT_KEY_2 '2'
#define N_PAINT_KEY_3 '3'
#define N_PAINT_KEY_4 '4'
#define N_PAINT_KEY_5 '5'
#define N_PAINT_KEY_6 '6'
#define N_PAINT_KEY_7 '7'
#define N_PAINT_KEY_8 '8'
#define N_PAINT_KEY_9 '9'
#define N_PAINT_KEY_0 '0'


// [ nonnon_paint_grab_n_drag.c ]

static bool n_paint_grabNdrag_onoff     = false;
static bool n_paint_grabNdrag_ctrl2drag = false;


// [ nonnon_paint.c ]

#define N_PAINT_APPNAME         "Nonnon Paint"
#define N_PAINT_APPNAME_LITERAL n_posix_literal( "Nonnon Paint" )

#define N_PAINT_MUTEX_REFRESH   n_posix_literal( "n_paint_refresh()" )


#ifndef NONNON_APPS

#define N_APPS_ICON_OFFSET_NONNON_PAINT ( 0 )

#endif // #ifndef NONNON_APPS


#define N_PAINT_REFRESH_NONE     ( 0 << 0 )
#define N_PAINT_REFRESH_CLIENT   ( 1 << 0 )
#define N_PAINT_REFRESH_WINDOW   ( 1 << 1 )
#define N_PAINT_REFRESH_SCROLL   ( 1 << 2 )
#define N_PAINT_REFRESH_ALL      ( 0xffff )

static bool n_paint_refresh_lock    = false;
static int  n_paint_refresh_combine = N_PAINT_REFRESH_NONE;

#define n_paint_refresh_flush( mode ) n_paint_refresh( NULL, 0,0, N_BMP_SX( n_paint_bmp_data ),N_BMP_SY( n_paint_bmp_data ), mode, 0 )
#define n_paint_refresh_all()         n_paint_refresh_flush( N_PAINT_REFRESH_ALL    )
#define n_paint_refresh_client()      n_paint_refresh_flush( N_PAINT_REFRESH_CLIENT )
#define n_paint_refresh_window()      n_paint_refresh_flush( N_PAINT_REFRESH_WINDOW )
#define n_paint_refresh_scroll()      n_paint_refresh_flush( N_PAINT_REFRESH_SCROLL )

#define N_PAINT_REFRESH_ID_NEWFILE  ( 1 )
#define N_PAINT_REFRESH_ID_WM_PAINT ( 2 )
#define N_PAINT_REFRESH_ID_SCROLL   ( 3 )
#define N_PAINT_REFRESH_ID_ZOOM     ( 4 )
#define N_PAINT_REFRESH_ID_PEN      ( 5 )
#define N_PAINT_REFRESH_ID_GRABBER  ( 6 )
#define N_PAINT_REFRESH_ID_LAYER    ( 7 )

#define n_paint_refresh_flush_id( mode, id ) n_paint_refresh( NULL, 0,0, N_BMP_SX( n_paint_bmp_data ),N_BMP_SY( n_paint_bmp_data ), mode, id )
#define n_paint_refresh_all_id( id )         n_paint_refresh_flush_id( N_PAINT_REFRESH_ALL   , id )
#define n_paint_refresh_client_id( id )      n_paint_refresh_flush_id( N_PAINT_REFRESH_CLIENT, id )
#define n_paint_refresh_window_id( id )      n_paint_refresh_flush_id( N_PAINT_REFRESH_WINDOW, id )
#define n_paint_refresh_scroll_id( id )      n_paint_refresh_flush_id( N_PAINT_REFRESH_SCROLL, id )


#define N_PAINT_FILTER_SCALE_LIL 0
#define N_PAINT_FILTER_SCALE_BIG 1
#define N_PAINT_FILTER_MIRROR    2
#define N_PAINT_FILTER_ROTATE_L  3
#define N_PAINT_FILTER_ROTATE_R  4
#define N_PAINT_FILTER_CLEAR     5
#define N_PAINT_FILTER_ALPHA_CLR 6
#define N_PAINT_FILTER_ALPHA_REV 7


#define N_PAINT_EXT_NUL n_posix_literal( ".___\0\0" )
#define N_PAINT_EXT_BMP n_posix_literal( ".bmp\0\0" )
#define N_PAINT_EXT_ICO n_posix_literal( ".ico\0\0" )
#define N_PAINT_EXT_CUR n_posix_literal( ".cur\0\0" )
#define N_PAINT_EXT_JPG n_posix_literal( ".jpg\0\0" )
#define N_PAINT_EXT_PNG n_posix_literal( ".png\0\0" )
#define N_PAINT_EXT_GIF n_posix_literal( ".gif\0\0" )
#define N_PAINT_EXT_LYR n_posix_literal( ".lyr\0\0" )

#define N_PAINT_FORMAT_NUL ( 0 )
#define N_PAINT_FORMAT_BMP ( 1 )
#define N_PAINT_FORMAT_ICO ( 2 )
#define N_PAINT_FORMAT_CUR ( 3 )
#define N_PAINT_FORMAT_JPG ( 4 )
#define N_PAINT_FORMAT_PNG ( 5 )
#define N_PAINT_FORMAT_LYR ( 6 )

#define n_paint_format_is_bmp( name ) ( n_string_path_ext_is_same( N_PAINT_EXT_BMP, name ) )
#define n_paint_format_is_ico( name ) ( n_string_path_ext_is_same( N_PAINT_EXT_ICO, name ) )
#define n_paint_format_is_cur( name ) ( n_string_path_ext_is_same( N_PAINT_EXT_CUR, name ) )
#define n_paint_format_is_jpg( name ) ( n_string_path_ext_is_same( N_PAINT_EXT_JPG, name ) )
#define n_paint_format_is_png( name ) ( n_string_path_ext_is_same( N_PAINT_EXT_PNG, name ) )
#define n_paint_format_is_lyr( name ) ( n_string_path_ext_is_same( N_PAINT_EXT_LYR, name ) )

#define n_paint_format_is_curico( name ) ( n_paint_format_is_ico( name ) || n_paint_format_is_cur( name ) )


// [!] : initialized by nonnon_paint_ini.c

static int               zoom;
static int               pensize, mix, edge, air;
static int               tooltype;
static bool              grid, pixelgrid, antishake, graycanvas, thumbnail;
static int               grabber;
static bool              n_paint_quick_eraser = false;


// [!] : initialized by nonnon_paint.c

static HWND              hwnd_main;
static HWND              hwnd_tool;
static HWND              hwnd_layr;
static n_win             nwin_main;
static n_win             nwin_tool;
static n_win             nwin_layr;
 
static HBITMAP           n_paint_dibsection;
static n_bmp            *n_paint_bmp_data;
static n_bmp            *n_paint_bmp_grab;
static n_bmp             n_paint_bmp_dbuf;
static n_bmp             n_paint_bmp_thmb;
static n_bmp             n_paint_bmp_name;
static n_curico          n_paint_curico;
static int               n_paint_format = N_PAINT_FORMAT_NUL;
static int               n_paint_bmp_name_count;

static n_bmp             n_paint_bmp_zoom_i;
static n_bmp             n_paint_bmp_zoom_o;

static n_posix_char     *n_paint_bmpname;
static n_posix_char     *n_paint_grbname;
static n_posix_char     *n_paint_prvname = NULL;

static n_win_scrollbar   n_paint_hscr;
static n_win_scrollbar   n_paint_vscr;

static n_win_titlemenu   n_paint_titlemenu;
static n_win_simplemenu  n_paint_simplemenu;

#ifdef _H_NONNON_WIN32_WIN_WINTAB

static n_wintab          n_paint_wintab;
static bool              n_paint_wintab_onoff;

#endif // #ifdef _H_NONNON_WIN32_WIN_WINTAB

static bool              n_paint_thread_onoff;

static s32               n_paint_prev_scrollx  = 0;
static s32               n_paint_prev_scrolly  = 0;
static HANDLE            n_paint_hmutex        = NULL;

static s32               n_paint_desktop_sx;
static s32               n_paint_desktop_sy;
static s32               n_paint_thumbnail_size;

static COLORREF          n_paint_frame_color_fg;
static COLORREF          n_paint_frame_color_bg;


extern void n_paint_refresh( HDC, s32, s32, s32, s32, int, int );

extern void n_paint_canvaspos( s32*, s32* );
extern void n_paint_colorpicker( void );

extern void n_paint_status( void );
extern void n_paint_title( void );

extern void n_paint_dialog_info( const n_posix_char* );
extern bool n_paint_dialog_yesno( const n_posix_char* );

extern bool n_paint_load( n_posix_char*, n_bmp*, n_curico* );

extern n_posix_char* n_paint_newname_new( void );

extern bool n_paint_is_innercanvas( void );


int
n_paint_pensize( void )
{

	int ret = pensize;

	if ( ret == 0 )
	{
		ret = 1;
	} else {
		ret = ( ret * 2 ) + 1;
	}

	return ret;
}


// [!] : canvas helper

#define N_PAINT_CANVAS_COLOR  n_bmp_argb( 0,128,128,128 )
#define N_PAINT_CANVAS_SIZE   128
#define N_PAINT_CANVAS_MARGIN  32

inline void
n_paint_margin_get( s32 *sx, s32 *sy )
{

	double scale  = (double) n_win_dpi( hwnd_main ) / 96.0;
	double margin = (double) N_PAINT_CANVAS_MARGIN * scale;

	//if ( n_direct2d_is_on() ) { margin = 0; }

	if ( sx != NULL ) { (*sx) = trunc( margin ); }
	if ( sy != NULL ) { (*sy) = trunc( margin ); }


	return;
}

inline void
n_paint_hamburger_get( s32 *x, s32 *y, s32 *sx, s32 *sy )
{

	s32 ox,oy,osx,osy; ox = oy = osx = osy = 0;

	s32 m; m = 0;

	n_paint_margin_get( &osx,&osy );

	if ( n_win_is_lefthanded() ) { ox = N_BMP_SX( &n_paint_bmp_dbuf ) - osx; } 
//if ( 1 ) { ox = N_BMP_SX( &n_paint_bmp_dbuf ) - osx; } 

	n_win_stdsize( hwnd_main, NULL, NULL, &m );

	if (  x != NULL ) { (* x) = ox + m; }
	if (  y != NULL ) { (* y) = oy + m; }
	if ( sx != NULL ) { (*sx) = osx - ( m * 2 ); }
	if ( sy != NULL ) { (*sy) = osy - ( m * 2 ); }


	return;
}


// [!] : zoom in/out support helper

#define N_PAINT_ZOOM_MAX  ( 200 )
#define N_PAINT_ZOOM_ZERO ( N_PAINT_ZOOM_MAX / 2 )

#define n_paint_is_zoom_in(  zoom ) ( zoom > N_PAINT_ZOOM_ZERO )
#define n_paint_is_zoom_out( zoom ) ( zoom < N_PAINT_ZOOM_ZERO )

int
n_paint_zoom_get( int zoom )
{

	if ( n_paint_is_zoom_in( zoom ) )
	{
		return ( zoom - N_PAINT_ZOOM_ZERO );
	} else
	if ( n_paint_is_zoom_out( zoom ) )
	{
		return ( N_PAINT_ZOOM_ZERO - zoom );
	}


	return 0;
}

int
n_paint_zoom_clamp( int prev, int zoom )
{

	if ( prev > N_PAINT_ZOOM_ZERO )
	{
		if ( zoom < ( N_PAINT_ZOOM_ZERO + 1 ) ) { zoom = N_PAINT_ZOOM_ZERO - 2; }
	} else
	if ( prev < N_PAINT_ZOOM_ZERO )
	{
		if ( zoom > ( N_PAINT_ZOOM_ZERO - 2 ) ) { zoom = N_PAINT_ZOOM_ZERO + 1; }
	}


	return zoom;
}

// internal
void
n_paint_zoom_bitmap2canvas( s32 *x, s32 *y, s32 *sx, s32 *sy )
{

	int z = n_paint_zoom_get( zoom );


	if ( n_paint_is_zoom_in( zoom ) )
	{
		if ( x  != NULL ) { (*x ) *= z; }
		if ( y  != NULL ) { (*y ) *= z; }
		if ( sx != NULL ) { (*sx) *= z; }
		if ( sy != NULL ) { (*sy) *= z; }
	} else
	if ( n_paint_is_zoom_out( zoom ) )
	{
		if ( x  != NULL ) { (*x ) /= z; }
		if ( y  != NULL ) { (*y ) /= z; }
		if ( sx != NULL ) { (*sx) /= z; }
		if ( sy != NULL ) { (*sy) /= z; }
	}


	return;
}

// internal
void
n_paint_zoom_canvas2bitmap( s32 *x, s32 *y, s32 *sx, s32 *sy )
{

	int z = n_paint_zoom_get( zoom );


	if ( n_paint_is_zoom_out( zoom ) )
	{
		if ( x  != NULL ) { (*x ) *= z; }
		if ( y  != NULL ) { (*y ) *= z; }
		if ( sx != NULL ) { (*sx) *= z; }
		if ( sy != NULL ) { (*sy) *= z; }
	} else
	if ( n_paint_is_zoom_in( zoom ) )
	{
		if ( x  != NULL ) { (*x ) /= z; }
		if ( y  != NULL ) { (*y ) /= z; }
		if ( sx != NULL ) { (*sx) /= z; }
		if ( sy != NULL ) { (*sy) /= z; }
	}


	return;
}

bool
n_paint_thumbnail_is_on( void )
{
//return false;

	return
	(
		( thumbnail )
		&&
		( ( n_paint_is_zoom_in( zoom ) )&&( 1 < n_paint_zoom_get( zoom ) ) )
		&&
		( nwin_main.state == SIZE_MAXIMIZED )
		&&
		( IsWindowEnabled( hwnd_main ) )
		&&
		( false == n_paint_hscr.drag_onoff )
		&&
		( false == n_paint_vscr.drag_onoff )
		//&&
		//( false == n_paint_grabNdrag_onoff )
	);
}


// [ nonnon_paint_colorhistory.c ]

extern void n_paint_colorhistory_add( u32 );
extern LRESULT CALLBACK n_paint_colorhistory_wndproc( HWND, UINT, WPARAM, LPARAM );


// [ nonnon_paint_colorsync.c ]

static UINT n_paint_sync_wm_synccolor = WM_NULL;


extern void n_sync_go( UINT, WPARAM, LPARAM );


// [ nonnon_paint_formatter.c ]

static n_posix_char *n_paint_formatter_name;
static n_bmp        *n_paint_formatter_bmp;


// [ nonnon_paint_grabber.c ]

#define N_PAINT_GRABBER_NEUTRAL              0
#define N_PAINT_GRABBER_SELECTING            1
#define N_PAINT_GRABBER_DRAG_OK              2
#define N_PAINT_GRABBER_DRAGGING             3
#define N_PAINT_GRABBER_STRETCH_PROPORTIONAL 4
#define N_PAINT_GRABBER_STRETCH_TRANSFORM    5

#define N_PAINT_GRABBER_IS_NEUTRAL()              ( grabber == N_PAINT_GRABBER_NEUTRAL              )
#define N_PAINT_GRABBER_IS_SELECTING()            ( grabber == N_PAINT_GRABBER_SELECTING            )
#define N_PAINT_GRABBER_IS_DRAG_OK()              ( grabber == N_PAINT_GRABBER_DRAG_OK              )
#define N_PAINT_GRABBER_IS_DRAGGING()             ( grabber == N_PAINT_GRABBER_DRAGGING             )
#define N_PAINT_GRABBER_IS_STRETCH_PROPORTIONAL() ( grabber == N_PAINT_GRABBER_STRETCH_PROPORTIONAL )
#define N_PAINT_GRABBER_IS_STRETCH_TRANSFORM()    ( grabber == N_PAINT_GRABBER_STRETCH_TRANSFORM    )


extern void n_paint_grabber_system_get( s32*, s32*, s32*, s32*, s32*, s32* );
extern void n_paint_grabber_reset( void );
extern void n_paint_grabber_status( void );
extern void n_paint_grabber_position_reset( void );
extern void n_paint_grabber_resync_auto( void );


static bool n_paint_grabber_finalize_onoff =  true;
static bool n_paint_grabber_wholegrb_onoff = false;
static bool n_paint_grabber_is_rotated     = false;
static int  n_paint_grabber_selected_index = 0;


// [ nonnon_paint_layer.c ]

#define N_PAINT_LAYER_MAX ( 16 )
#define N_PAINT_LAYER_CCH ( 32 )

typedef struct {

	n_posix_char name[ N_PAINT_LAYER_CCH ];
	n_bmp        bmp_data;
	n_bmp        bmp_grab;
	bool         visible;
	int          percent;
	int          blur;

	// Cache

	double       blend;

} n_paint_layer;

#define n_paint_layer_zero( p ) n_memory_zero( p, sizeof( n_paint_layer ) )


static bool              n_paint_layer_onoff = false;
static int               n_paint_layer_count = N_PAINT_LAYER_MAX;
static n_paint_layer    *n_paint_layer_data;
static n_paint_layer    *n_paint_layer_copy;
static n_bmp             n_paint_layer_as_one;
static n_win_txtbox      n_paint_layer_txtbox;
static n_win_txtbox      n_paint_layer_rename;
static bool              n_paint_layer_rename_onoff  = false;
static int               n_paint_layer_rename_target = 0;
static n_ini             n_paint_layer_ini;
static bool              n_paint_layer_shade_onoff   = false;
static bool              n_paint_layer_scroll_onoff  = false;
static int               n_paint_layer_menu_target   = -1;
static int               n_paint_layer_multiselect   = 0;

//static n_win_statusbar_ownerdraw n_paint_layer_statusbar;


extern void n_paint_layer_grabber_onoff( bool );


// [ nonnon_paint_refresh.c ]

extern inline u32 n_paint_canvas_grabber_pixel( n_bmp*, s32, s32, u32 );


// [ nonnon_paint_tool.c ]

#define N_PAINT_TOOL_TYPE_NONE  0
#define N_PAINT_TOOL_TYPE_PEN   1
#define N_PAINT_TOOL_TYPE_FILL  2
#define N_PAINT_TOOL_TYPE_GRAB  3


#define N_PAINT_TOOL_H_BTN_00_00  n_paint_tool_hgui[ 0 ]
#define N_PAINT_TOOL_H_BTN_01_00  n_paint_tool_hgui[ 1 ]
#define N_PAINT_TOOL_H_BTN_02_00  n_paint_tool_hgui[ 2 ]
#define N_PAINT_TOOL_H_BTN_03_00  n_paint_tool_hgui[ 3 ]
#define N_PAINT_TOOL_H_BTN_04_00  n_paint_tool_hgui[ 4 ]

#define N_PAINT_TOOL_H_BTN_00_01  n_paint_tool_hgui[ 0 + 5 ]
#define N_PAINT_TOOL_H_BTN_01_01  n_paint_tool_hgui[ 1 + 5 ]
#define N_PAINT_TOOL_H_BTN_02_01  n_paint_tool_hgui[ 2 + 5 ]
#define N_PAINT_TOOL_H_BTN_03_01  n_paint_tool_hgui[ 3 + 5 ]
#define N_PAINT_TOOL_H_BTN_04_01  n_paint_tool_hgui[ 4 + 5 ]

#define N_PAINT_TOOL_H_BTN_00_02  n_paint_tool_hgui[ 0 + 10 ]
#define N_PAINT_TOOL_H_BTN_01_02  n_paint_tool_hgui[ 1 + 10 ]
#define N_PAINT_TOOL_H_BTN_02_02  n_paint_tool_hgui[ 2 + 10 ]
#define N_PAINT_TOOL_H_BTN_03_02  n_paint_tool_hgui[ 3 + 10 ]
#define N_PAINT_TOOL_H_BTN_04_02  n_paint_tool_hgui[ 4 + 10 ]

#define N_PAINT_TOOL_GUI_MAX                       ( 5 + 10 )


#define N_PAINT_TOOL_H_SCR_SIZE   ( &n_paint_tool_hscr[ 0 ] )
#define N_PAINT_TOOL_H_SCR_MIX    ( &n_paint_tool_hscr[ 1 ] )
#define N_PAINT_TOOL_H_SCR_EDGE   ( &n_paint_tool_hscr[ 2 ] )
#define N_PAINT_TOOL_H_SCR_AIR    ( &n_paint_tool_hscr[ 3 ] )
#define N_PAINT_TOOL_H_SCR_ZOOM   ( &n_paint_tool_hscr[ 4 ] )

#define N_PAINT_TOOL_SCR_MAX                            5




static n_win_colorpicker cp;
static HWND              n_paint_hpopup;

static HWND              n_paint_tool_hgui[ N_PAINT_TOOL_GUI_MAX ];
static n_win_scroller    n_paint_tool_hscr[ N_PAINT_TOOL_SCR_MAX ];


extern void n_paint_tool_exit( void );
extern void n_paint_tool_saveicon_refresh( bool );
extern void n_paint_tool_scrollbar_updown( n_win_scroller*, int );


// [ nonnon_paint_tool_grabber.c ]

static n_win_statusbar_ownerdraw n_paint_tool_grabber_status;

static int    n_paint_tool_grabber_csy;
static bool   n_paint_tool_per_pixel_alpha_onoff;
static int    n_paint_tool_blend;
static double n_paint_tool_blend_ratio;

extern void n_paint_tool_grabber_exit( void );
extern void n_paint_tool_grabber_onoff( bool );
//extern void n_paint_tool_grabber_trans_onoff( bool );
extern void n_paint_tool_grabber_blend_zero( void );
extern void n_paint_tool_grabber_resize( void );
extern void n_paint_tool_grabber_proc( HWND, UINT, WPARAM, LPARAM );


inline u32
n_paint_tool_color_transparent_get( void )
{

	//return n_bmp_alpha_invisible_pixel( n_bmp_argb( cp.a, cp.r, cp.g, cp.b ) );

	if ( false == N_PAINT_GRABBER_IS_NEUTRAL() )
	{
		return n_bmp_white_invisible;
	} else
	if ( n_paint_tool_per_pixel_alpha_onoff )
	{
		return n_bmp_white_invisible;
	} else
	if ( n_paint_layer_onoff )
	{
		return n_bmp_white_invisible;
	}


	return n_bmp_white;
}


// [ nonnon_paint_pen.c ]

#define N_PAINT_PEN_STRAIGHTLINE_VK VK_SPACE

static int    n_paint_pen_radius   = 0;
static u32    n_paint_pen_color    = 0;
static double n_paint_pen_blend    = 0;
static bool   n_paint_pen_start    = false;
static bool   n_paint_is_shiftzoom = false;

static s32    n_paint_pen_start_x;
static s32    n_paint_pen_start_y;
static bool   n_paint_pen_straight_line = false;

void
n_paint_pen_cursor_default( HWND hwnd )
{

	if ( tooltype == N_PAINT_TOOL_TYPE_PEN  )
	{
		n_win_cursor_add_literal( hwnd, "NONNON_PAINT_PEN"  );
	} else
	if ( tooltype == N_PAINT_TOOL_TYPE_FILL )
	{
		n_win_cursor_add_literal( hwnd, "NONNON_PAINT_FILL" );
	}

	return;
}

static bool n_paint_hamburger_onoff      = false;
static bool n_paint_hamburger_is_hovered = false;
static bool n_paint_hamburger_is_started = false;

bool
n_paint_on_setcursor_condition( void )
{
//return false;

	s32 x,y,sx,sy; n_paint_hamburger_get( &x,&y,&sx,&sy );

	if ( n_win_is_hovered_offset( hwnd_main, x,y,sx,sy ) )
	{
		if (
			( n_paint_pen_start           == false )
			&&
			( n_paint_grabNdrag_ctrl2drag == false )
			//&&
			//( n_paint_quick_eraser        == false )
		)
		{
			n_win_cursor_add( NULL, IDC_ARROW );

			if ( tooltype == N_PAINT_TOOL_TYPE_GRAB )
			{
				return n_paint_hamburger_onoff;
			} else {
				return true;
			}
		}
	}

	if (
		( n_paint_hscr.hwnd == n_win_cursor2hwnd_relative( hwnd_main ) )
		||
		( n_paint_vscr.hwnd == n_win_cursor2hwnd_relative( hwnd_main ) )
	)
	{
		return true;
	}

	if (
		( n_paint_grabber_wholegrb_onoff )
		&&
		( tooltype == N_PAINT_TOOL_TYPE_GRAB )
	)
	{
		//
	} else
	if (
		( n_paint_grabber_wholegrb_onoff )
		&&
		( tooltype != N_PAINT_TOOL_TYPE_GRAB )
		&&
		( grabber )
		&&
		( n_paint_layer_data[ n_paint_layer_txtbox.select_cch_y ].visible )
	)
	{
		//
	} else
	if ( n_paint_layer_onoff )
	{
		int y1 = n_paint_layer_txtbox.select_cch_y;
		int y2 = n_paint_grabber_selected_index;

		if ( false == n_paint_layer_data[ y1 ].visible )
		{
			return true;
		} else
		if ( ( grabber )&&( false == n_paint_layer_data[ y2 ].visible ) )
		{
			return true;
		}
	}


	return false;
}

bool
n_paint_on_setcursor( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {

	case WM_SETCURSOR :

		if ( n_paint_is_shiftzoom ) { break; }

		if ( n_paint_pen_start ) { break; }


		s32 x,y,sx,sy; n_paint_hamburger_get( &x,&y,&sx,&sy );

		if ( n_win_is_hovered_offset( hwnd, x,y,sx,sy ) )
		{
			n_win_cursor_add( NULL, IDC_ARROW );

			return true;
		}


		if (
			( n_paint_hscr.hwnd == n_win_cursor2hwnd_relative( hwnd_main ) )
			||
			( n_paint_vscr.hwnd == n_win_cursor2hwnd_relative( hwnd_main ) )
		)
		{
			n_win_cursor_add( NULL, IDC_ARROW );

			return true;
		}

		if ( n_paint_on_setcursor_condition() )
		{
			s32 sx = nwin_main.csx;
			s32 sy = nwin_main.csy;

			if ( n_win_is_hovered_offset( hwnd_main, 0,0,sx,sy ) )
			{
				n_win_cursor_add( NULL, IDC_NO );

				return true;
			}
		}

	break;

	} // switch


	return false;
}


// [ nonnon_paint_layer.c : #2 ]

static n_win_check n_paint_layer_chk_wholegrb;
static n_win_check n_paint_layer_chk_wholepvw;

static bool n_paint_whole_preview_onoff = false;

bool
n_paint_whole_preview( bool onoff )
{

	bool ret = false;
	if ( onoff != n_paint_whole_preview_onoff )
	{
		ret = true;
	}

	n_paint_whole_preview_onoff = onoff;


	return ret;
}


// [ nonnon_paint_layer.c : #3 ]

static n_posix_char *n_paint_layer_name_main = NULL;

void
n_paint_layer_name_exit( void )
{

	n_memory_free( n_paint_layer_name_main );

	n_paint_layer_name_main = NULL;


	return;
}

void
n_paint_layer_name_init( n_posix_char *target )
{

	n_paint_layer_name_exit();

	n_paint_layer_name_main = n_string_carboncopy( target );


	return;
}


