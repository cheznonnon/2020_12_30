// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_oc_item_multifocus_debug( const n_posix_char *path )
{

	int count = n_string_path_multiple_count( path );
n_posix_debug_literal( " %d ", count );

	int i = 0;
	while( 1 )
	{

		if ( i >= count ) { break; }

		n_posix_char *str = n_string_path_multiple_new( path, i );
n_posix_debug_literal( " %s ", str );

		n_string_path_free( str );

		i++;

	}


	return;
}

void
n_oc_item_multifocus_move_on( n_oc_item *p, int index )
{

	if ( n_oc_item_error( p ) ) { return; }


	if ( index < 0 ) { return; }


	int i = 0;
	while( 1 )
	{
		if ( i >= p->count ) { break; }

		if ( ( i != index )&&( p->multifocus[ i ] ) )
		{
			p->multifocus_move[ i ] =  true;
			p->multifocus     [ i ] = false;
		}

		i++;
	}


	return;
}

void
n_oc_item_multifocus_fade_on( n_oc_item *p, int index )
{

	if ( n_oc_item_error( p ) ) { return; }


	if (    index < 0 ) { return; }
	if ( p->hover < 0 ) { return; }


	int i = 0;
	while( 1 )
	{
		if ( i >= p->count ) { break; }

		if ( ( i != p->hover )&&( p->multifocus[ i ] ) )
		{
			p->multifocus_move[ i ] = false;
			p->multifocus_fade[ i ] =  true;
		}

		i++;
	}


	return;
}

void
n_oc_item_multifocus_fade_off( n_oc_item *p )
{

	if ( n_oc_item_error( p ) ) { return; }


	int i = 0;
	while( 1 )
	{
		if ( i >= p->count ) { break; }

		if ( p->multifocus[ i ] )
		{
			u32 color_fg = n_oc_item_color_bg( p, i );
			n_bmp_fade_always_on( &p->fade[ i ], p->fade[ i ].color_fg, color_fg );

			p->multifocus     [ i ] = false;
			p->multifocus_move[ i ] = false;
			p->multifocus_fade[ i ] =  true;
		}

		i++;
	}


	return;
}

void
n_oc_item_multifocus_fade_always_on( n_oc_item *p, u32 color_fg )
{

	if ( n_oc_item_error( p ) ) { return; }


	int i = 0;
	while( 1 )
	{
		if ( i >= p->count ) { break; }

		if ( p->multifocus[ i ] )
		{
			n_bmp_fade_always_on( &p->fade[ i ], p->fade[ i ].color_fg, color_fg );
		}

		i++;
	}


	return;
}

void
n_oc_item_multifocus_off_all( n_oc_item *p )
{

	if ( n_oc_item_error( p ) ) { return; }


	int i = 0;
	while( 1 )
	{
		if ( i >= p->count ) { break; }

		p->multifocus        [ i ] = false;
		p->patch_forced_focus[ i ] = false;
		//p->patch_forced_frame[ i ] = false;

		i++;
	}


	return;
}

void
n_oc_item_multifocus_off( n_oc_item *p )
{

	if ( n_oc_item_error( p ) ) { return; }


	int i = 0;
	while( 1 )
	{
		if ( i >= p->count ) { break; }

		p->multifocus[ i ] = false;

		i++;
	}


	return;
}

void
n_oc_item_multifocus_on_all( n_oc_item *p )
{

	if ( n_oc_item_error( p ) ) { return; }


	int i = 0;
	while( 1 )
	{
		if ( i >= p->count ) { break; }

		p->multifocus[ i ] = true;

		i++;
	}


	return;
}

int
n_oc_item_multifocus_single( n_oc_item *p )
{

	// [!] : for a single focus

	if ( n_oc_item_error( p ) ) { return N_ORANGECAT_NOTHING; }


	int i = 0;
	while( 1 )
	{
		if ( i >= p->count ) { i = N_ORANGECAT_NOTHING; break; }

		if ( p->multifocus[ i ] ) { break; }

		i++;
	}


	return i;
}

int
n_oc_item_multifocus_count( n_oc_item *p )
{

	if ( n_oc_item_error( p ) ) { return 0; }


	int count = 0;


	int i = 0;
	while( 1 )
	{
		if ( i >= p->count ) { break; }

		if ( p->multifocus[ i ] ) { count++; }

		i++;
	}


	return count;
}

int
n_oc_item_multifocus_count_forced_frame( n_oc_item *p )
{

	if ( n_oc_item_error( p ) ) { return N_ORANGECAT_NOTHING; }


	int count = 0;


	int i = 0;
	while( 1 )
	{
		if ( i >= p->count ) { break; }

		if ( p->patch_forced_frame[ i ] ) { count++; }

		i++;
	}


	return count;
}

int
n_oc_item_multifocus_forced_count( n_oc_item *p )
{

	if ( n_oc_item_error( p ) ) { return 0; }


	int count = 0;


	int i = 0;
	while( 1 )
	{
		if ( i >= p->count ) { break; }

		if ( p->patch_forced_focus[ i ] ) { count++; }

		i++;
	}


	return count;
}

void
n_oc_item_multifocus_forced_sync( n_oc_item *p )
{

	if ( n_oc_item_error( p ) ) { return; }


	int i = 0;
	while( 1 )
	{
		if ( i >= p->count ) { break; }

		if ( p->patch_forced_focus[ i ] )
		{
			p->multifocus[ i ] = true;
		}

		i++;
	}


	return;
}

void
n_oc_item_multifocus_forced_frame( n_oc_item *p )
{

	if ( n_oc_item_error( p ) ) { return; }


	int i = 0;
	while( 1 )
	{//break;
		if ( i >= p->count ) { break; }

		if ( p->multifocus[ i ] )
		{
			if ( p->patch_forced_frame[ i ] == false )
			{
				p->patch_forced_frame[ i ] = true;

				n_bmp_fade_always_on( &p->fade[ i ], n_oc_item_color_bg( p, i ), oc_color.item_focus );
			}
		}

		i++;
	}


	return;
}

void
n_oc_item_multifocus_forced_fade_off( n_oc_item *p )
{

	if ( n_oc_item_error( p ) ) { return; }


	int i = 0;
	while( 1 )
	{
		if ( i >= p->count ) { break; }

		n_bmp_fade_init( &p->fade[ i ], oc_color.bg );


		i++;
	}


	return;
}

void
n_oc_item_multifocus_sync_image( n_oc_item *p )
{

	if ( n_oc_item_error( p ) ) { return; }


	extern void n_oc_item_sync_image( n_oc_item*, int, u32, bool, bool );

	int i = 0;
	while( 1 )
	{
		if ( i >= p->count ) { break; }

		if ( p->multifocus[ i ] ) { n_oc_item_sync_image( p, i, 0, false, true ); }

		i++;
	}


	return;
}

bool
n_oc_item_multifocus_is_on( n_oc_item *p )
{
	return ( 1 <= n_oc_item_multifocus_count( p ) );
}

void
n_oc_item_multifocus_path2focus( n_oc_item *p, const n_posix_char *path, bool autoscroll )
{

	if ( n_oc_item_error( p ) ) { return; }

	if ( p->count == 0 ) { return; }

	if ( n_string_is_empty( path ) ) { return; }


	bool is_first = true;


	int i = 0;
	while( 1 )
	{

		const n_posix_char *name = &path[ i ];
		if ( name[ 0 ] == N_STRING_CHAR_NUL ) { break; }

		n_posix_char *str;
		if ( n_string_path_is_drivename( path ) )
		{
			str = n_string_path_carboncopy( name );
		} else {
			str = n_string_path_name_new  ( name );
		}
//n_posix_debug_literal( "%s\n%s", name, str );

		size_t j = 0;
		while( 1 )
		{//break;

//n_posix_debug_literal( "%s\n%s", str, n_dir_name( &p->dir, j ) );

			if ( n_string_is_same( str, n_dir_name( &p->dir, j ) ) )
			{
				p->multifocus[ j ] = true;
				if ( is_first )
				{
					is_first = false;

					p->load_item[ j ] = N_ORANGECAT_LOAD_MAIN;
					n_oc_item_gdi2bitmap( p, j );

					if ( autoscroll ) { n_oc_item_autoscroll( p, j, N_OC_ITEM_AUTOSCROLL_CENTERING ); }
				}
			}

			j++;
			if ( j >= n_dir_all( &p->dir ) ) { break; }
		}

		i += n_posix_strlen( name ) + 1;

		n_string_path_free( str );

	}


	return;
}

void
n_oc_item_multifocus_path2focus_light( n_oc_item *p, const n_posix_char *path, bool fade_init, bool autoscroll )
{
//return;

	if ( n_oc_item_error( p ) ) { return; }

	if ( p->count == 0 ) { return; }

	if ( n_string_is_empty( path ) ) { return; }


	int i = 0;
	while( 1 )
	{

		const n_posix_char *name = &path[ i ];
		if ( name[ 0 ] == N_STRING_CHAR_NUL ) { break; }

		n_posix_char *str;
		if ( n_string_path_is_drivename( path ) )
		{
			str = n_string_path_carboncopy( name );
		} else {
			str = n_string_path_name_new  ( name );
		}
//n_posix_debug_literal( "%s\n%s", name, str );

		size_t j = 0;
		while( 1 )
		{//break;

//n_posix_debug_literal( "%s\n%s", str, n_dir_name( &p->dir, j ) );

			if ( n_string_is_same( str, n_dir_name( &p->dir, j ) ) )
			{
				p->multifocus[ j ] = true;

				if ( fade_init )
				{
					//p->patch_forced_frame[ j ] = true;
					n_bmp_fade_init( &p->fade[ j ], oc_color.item_focus );
				}

				n_oc_item_autoscroll( p, j, N_OC_ITEM_AUTOSCROLL_CENTERING );
			}

			j++;
			if ( j >= n_dir_all( &p->dir ) ) { break; }
		}

		i += n_posix_strlen( name ) + 1;

		n_string_path_free( str );

	}


	return;
}

void
n_oc_item_multifocus_delete( n_oc_item *p )
{

	n_posix_char *str   = n_oc_item_multifocus_focus2path_new( p );
	int           count = n_string_path_multiple_count( str );

	int i = 0;
	while( 1 )
	{

		if ( i >= count ) { break; }

		n_posix_char *s = n_string_path_multiple_new( str, i );
//n_posix_debug_literal( "%s", s );

		bool ret = n_win_filer_delete( game.hwnd, s, NULL );
		if ( ret ) { n_project_dialog_info( game.hwnd, n_project_string_error ); }

		n_string_path_free( s );

		i++;

	}

	n_string_path_free( str );


	return;
}

void
n_oc_item_multifocus_focus2path( n_oc_item *p, n_posix_char *path )
{

	if ( n_oc_item_error( p ) ) { return; }


	if ( path == NULL ) { return; }


	if ( p->count <= 0 )
	{

		n_string_path_copy( N_STRING_EMPTY, path );

		return;
	}


	int i = 0;
	int j = 0;
	while( 1 )
	{
		if ( i >= p->count ) { break; }

		if ( p->multifocus[ i ] )
		{
			n_posix_char *dir  = n_dir_path( &p->dir, i );
			n_posix_char *name = n_dir_name( &p->dir, i );
			n_posix_char *str  = n_string_path_make_new( dir, name );

			j += n_posix_sprintf_literal( &path[ j ], "%s", str );

			n_string_path_free( str );

			j++;
		}

		i++;
	}
//n_posix_debug_literal( " %s ", path );


	return;
}

n_posix_char*
n_oc_item_multifocus_focus2path_new( n_oc_item *p )
{

	// [!] : you need to n_string_path_free() a returned variable

	int i = 0;
	int j = 0;
	while( 1 )
	{
		if ( i >= p->count ) { break; }

		if ( p->multifocus[ i ] )
		{
			n_posix_char *path = n_dir_path( &p->dir, i );
			n_posix_char *name = n_dir_name( &p->dir, i );
			n_posix_char *str  = n_string_path_make_new( path, name );

			j += n_posix_strlen( str );

			n_string_path_free( str );

			// [!] : space for NUL('\0')
			j++;
		}

		i++;
	}


	n_posix_char *ret = n_string_path_new( j );
	n_oc_item_multifocus_focus2path( p, ret );


	return ret;
}

bool
n_oc_item_multifocus_dnd( const n_posix_char *f, const n_posix_char *t, int drag, bool *is_cancelled )
{
//n_posix_debug_literal( "F:%s\nT:%s", f, t ); return true;

	if ( n_string_is_empty( f ) ) { return false; }
	if ( n_string_is_empty( t ) ) { return false; }


	//if ( n_string_is_same( f, t ) ) { return false; }


	int count = n_string_path_multiple_count( f );
//n_posix_debug_literal( " %d ", count );
	if ( count == 0 ) { return true; }


	bool is_exec   = false;
	bool is_same   = false;
	bool is_locked = false;

	{

		n_posix_char *path;
		n_posix_char *args;

		if ( n_string_path_ext_is_same( N_ISHELLLINK_EXT, t ) )
		{
			path = n_string_path_new( N_OC_LNK2PATH_CCH_MAX );
			args = n_string_path_new( N_OC_LNK2PATH_CCH_MAX );
			n_oc_lnk2path( t, path, args );
		} else {
			path = n_string_path_carboncopy( t );
			args = n_string_path_carboncopy( N_STRING_EMPTY );
		}


		if ( n_posix_stat_is_file( path ) ) { is_exec = true; }

		n_string_path_free( path );
		n_string_path_free( args );

	}

	{

		n_posix_char *upper = n_string_path_upperfolder_new( f );

		is_same = n_string_is_same( upper, t );
//n_posix_debug_literal( " %d ", is_same );

		n_string_path_free( upper );

	}

	int i = 0;
	while( 1 )
	{//break;

		n_posix_char *str = n_string_path_multiple_new( f, i );
//n_posix_debug_literal( " %s ", str );

		if (
			( is_exec == false )
			&&
			( drag == N_ORANGECAT_DRAG_LBUTTON )
			&&
			( is_same == false )
		)
		{
			is_locked = n_filer_is_locked( str );
			if ( is_locked ) { break; }
		}


		n_string_path_free( str );


		i++;
		if ( i >= count ) { break; }
	}
//n_posix_debug_literal( " %d ", is_locked );

	if ( is_locked ) { return true; }
//return true;


	bool ret = false;

	bool explorer_refresh = false;

	n_win_message_post( HWND_BROADCAST, oc.msg_dnd_onoff, true, 0 );

	i = 0;
	while( 1 )
	{

		n_posix_char *str = n_string_path_multiple_new( f, i );
//n_posix_debug_literal( " %s ", str );

		bool b = n_oc_dnd( str, t, drag, false, is_cancelled );
//n_posix_debug_literal( " %d ", b );
		if (
			( b == false )
			&&
			( ( is_cancelled != NULL )&&( (*is_cancelled) == false ) )
		)
		{
			explorer_refresh = true;
		}
		ret |= b;
//n_posix_debug_literal( " %d %d ", b, ret );

		n_string_path_free( str );


		i++;
		if ( i >= count ) { break; }
	}

	n_win_message_post( HWND_BROADCAST, oc.msg_dnd_onoff, false, 0 );

	if ( explorer_refresh )
	{
		n_explorer_refresh( false );
	}

//n_posix_debug_literal( " %d ", ret );
	return ret;
}


