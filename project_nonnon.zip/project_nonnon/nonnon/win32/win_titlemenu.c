// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [Limitaion]
//
//	one main window only
//	use as template




#ifndef _H_NONNON_WIN32_WIN_TITLEMENU
#define _H_NONNON_WIN32_WIN_TITLEMENU




#include "./win_menu.c"
#include "./win_simplemenu.c"




typedef struct {

	HHOOK             hhook;
	HWND              hwnd;
	HMENU             hmenu;
	n_win_simplemenu *smenu;
	HWND              hwnd_menu;
	bool              onoff;

} n_win_titlemenu;




static n_win_titlemenu *n_win_titlemenu_target = NULL;




#define n_win_titlemenu_zero( p ) n_memory_zero( p, sizeof( n_win_titlemenu ) )

LRESULT CALLBACK
n_win_titlemenu_MouseProc( int nCode, WPARAM wParam, LPARAM lParam )
{

	n_win_titlemenu *p = n_win_titlemenu_target;

	if ( ( p != NULL )&&( nCode == HC_ACTION ) )
	{

		MOUSEHOOKSTRUCT *mh = (void*) lParam;
//n_win_hwndprintf_literal( mh->hwnd, " %d %d ", wParam, mh->wHitTestCode );

		if ( wParam == WM_NCRBUTTONDOWN ) // 164
		{
			if ( mh->wHitTestCode == HTCAPTION ) // 2
			{
				if ( ( p->hwnd == mh->hwnd )&&( p->onoff ) )
				{
#ifdef _H_NONNON_WIN32_WIN_COMBOBOX
					if ( IsWindow( n_win_combo_hpopup ) )
					{
						n_win_message_send( n_win_combo_hpopup, WM_CLOSE, 0, 0 );
					}
#endif // #ifndef _H_NONNON_WIN32_WIN_COMBOBOX

					if ( p->hmenu != NULL )
					{
						n_win_menu_popup_show( p->hmenu, p->hwnd );
					} else
					if ( p->smenu != NULL )
					{
//n_posix_debug_literal( "" );
						n_win_simplemenu_hide( p->smenu );

						SetActiveWindow( p->hwnd );

						n_win_simplemenu_show( p->smenu, p->hwnd );
					}
				}

				return true;
			} else
			if ( mh->wHitTestCode == HTSYSMENU ) // 3
			{
				if ( ( p->hwnd == mh->hwnd )&&( p->onoff ) )
				{
					if ( p->smenu != NULL )
					{
						if ( IsWindow( p->smenu->hwnd ) )
						{
							n_win_message_send( p->smenu->hwnd, WM_CLOSE, 0, 0 );
						}
					}
				}
			}
		} else
		if ( wParam == WM_NCLBUTTONDOWN )
		{
			static int doubleclick = 0;
			static u32 tickcount   = 0;

			if ( mh->wHitTestCode == HTSYSMENU ) // 3
			{

				if ( tickcount < n_posix_tickcount() )
				{
					doubleclick = 0;
//n_win_menu_popup_show( GetSystemMenu( mh->hwnd, false ), mh->hwnd );
				}

				if ( doubleclick == 0 ) { tickcount = n_posix_tickcount() + GetDoubleClickTime(); }

				doubleclick++;
				if ( doubleclick >= 2 )
				{
					if ( tickcount > n_posix_tickcount() )
					{
						doubleclick = 0;
						n_win_message_post( mh->hwnd, WM_CLOSE, 0, 0 );
					}
				}

				return true;
			}
		}// else
	}

	return CallNextHookEx( p->hhook, nCode, wParam, lParam );
}

#define n_win_titlemenu_init( p, h ) n_win_titlemenu_init_main( p, h, NULL )

void
n_win_titlemenu_init_main( n_win_titlemenu *p, HWND hwnd, n_win_simplemenu *smenu )
{

	p->onoff = true;
	p->hwnd  = hwnd;
	p->hhook = SetWindowsHookEx( WH_MOUSE, n_win_titlemenu_MouseProc, GetModuleHandle( NULL ), GetWindowThreadProcessId( hwnd, NULL ) );

	if ( smenu == NULL )
	{
		p->hmenu = n_win_menu_popup_hmenu_init();
	} else {
		p->smenu = smenu;
	}

	n_win_titlemenu_target = p;


	return;
}

void
n_win_titlemenu_exit( n_win_titlemenu *p )
{

	UnhookWindowsHookEx( p->hhook );

	if ( p->hmenu != NULL )
	{
		n_win_menu_popup_hmenu_exit( p->hmenu );
	}

	n_win_titlemenu_zero( p );


	return;
}


#endif // _H_NONNON_WIN32_WIN_TITLEMENU


