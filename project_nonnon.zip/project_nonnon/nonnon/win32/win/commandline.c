// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_COMMANDLINE
#define _H_NONNON_WIN32_WIN_COMMANDLINE




#include "../../neutral/string.c"
#include "../../neutral/string_path.c"




#include <shellapi.h>




int
n_win_exepath_cch( void )
{

	// [x] : WinXP or earlier : GetModuleFileName() always succeed
	//
	//	GetLastError() returns zero

	int cch = MAX_PATH;
	while( 1 )
	{

		n_posix_char *str = n_string_new( cch );

		GetModuleFileName( NULL, str, cch );
		DWORD dw_ret = GetLastError();

		n_string_free( str );

		if ( dw_ret == ERROR_INSUFFICIENT_BUFFER )
		{
			cch++;
		} else {
//n_posix_debug_litral( " %d ", (int) dw_ret );
			break;
		}

	}


	return cch;
}

//#define n_win_exepath( str, cch ) GetModuleFileName( NULL, str, cch )

void
n_win_exepath( n_posix_char *str, int cch )
{

	if ( str == NULL ) { return; }
	if ( cch <= 0 ) { n_string_truncate( str ); return; }


	n_string_zero( str, cch );


	// [Mechanism] : GetLastError()
	//
	//	ERROR_FILE_NOT_FOUND(2) will be returned in some versions
	//
	//	9x	ERROR_SUCCESS
	//	NT4.0	ERROR_FILE_NOT_FOUND
	//	2000	ERROR_FILE_NOT_FOUND
	//	XP	ERROR_FILE_NOT_FOUND
	//	8.1	ERROR_SUCCESS
	//
	//	ERROR_INSUFFICIENT_BUFFER(122) will be returned when lack of buffer

	DWORD ret = GetModuleFileName( NULL, str, cch );
	DWORD err = GetLastError();
//n_posix_debug_literal( "%s : %d : %d", str, ret, err );

	if ( ( ret == 0 )||( err == ERROR_INSUFFICIENT_BUFFER ) ) { n_string_truncate( str ); }


	return;
}

n_posix_char*
n_win_exepath_new( void )
{

	// [!] : you need to n_string_path_free() a returned variable

	int           cch = n_win_exepath_cch();
	n_posix_char *ret = n_string_path_new( cch );


	n_win_exepath( ret, cch );


	return ret;
}

void
n_win_exedir2curdir( void )
{

	n_posix_char *exe = n_win_exepath_new();
//n_posix_debug( exe );

	n_string_path_folder_change( exe );

	n_string_path_free( exe );


	return;
}

#define n_win_commandline_cch() n_win_commandline( NULL )

size_t
n_win_commandline( n_posix_char *path )
{

	// [Mechanism] : don't use WinMain()'s lpcmd
	//
	//	[ Possibilities ]
	//
	//	a : via Explorer	fully qualified path only
	//	b : via command prompt	any pattern available
	//
	//	[ Example ]
	//
	//	a : "C:\folder\name.exe"
	//	b : "folder_name.exe\name.exe"
	//	b : name
	//	b : NamE.Exe


	// [!] : don't touch lpcmd's data

	n_posix_char *lpcmd = GetCommandLine();
//n_posix_debug( lpcmd );


	// [!] : skip argv[ 0 ]

	bool doublequote = false;

	if ( lpcmd[ 0 ] == N_STRING_CHAR_DQUOTE )
	{
		doublequote = true;
		lpcmd = &lpcmd[ 1 ];
	}

	int i = 0;
	while( 1 )
	{

		if ( doublequote == false )
		{
			if ( lpcmd[ i ] == N_STRING_CHAR_SPACE  ) { i += 1; break; }
		} else {
			if ( lpcmd[ i ] == N_STRING_CHAR_DQUOTE ) { i += 2; break; }
		}


		i++;
		if ( lpcmd[ i ] == N_STRING_CHAR_NUL ) { break; }
	}

	lpcmd = &lpcmd[ i ];
//n_posix_debug( lpcmd );


	// [!] : sanitizing
	//
	//	don't use n_string_doublequote_del()
	//	misbehave in case of "-label C:\ "Windows XP""


	n_posix_char *cmd = n_string_path_carboncopy( lpcmd );

	n_string_remove_blank( cmd, cmd );

	if ( 1 == n_string_parameter_count_literal( cmd, " ", "\"" ) )
	{
		n_string_doublequote_del( cmd, cmd );
	}
//n_posix_debug_literal( "%s\n%s", lpcmd, cmd );


	n_posix_char *lng = n_string_path_short2long_new( cmd );

	if ( path != NULL ) { n_string_copy( lng, path ); }
//n_posix_debug( path );

	size_t cch = n_posix_strlen( lng );


	n_string_path_free( cmd );
	n_string_path_free( lng );


	return cch;
}

n_posix_char*
n_win_commandline_new( void )
{

	// [!] : you need to n_string_path_free() a returned variable

	size_t        cch = n_win_commandline_cch();
	n_posix_char *ret = n_string_path_new( cch );


	n_win_commandline( ret );


	return ret;
}

size_t
n_win_dropfiles_multiple_cch( HWND hwnd, WPARAM wparam )
{

	size_t cch = 0;

#ifdef _H_NONNON_WIN32_OLE_IDROPTARGET

	cch = n_IDropTarget_path_cch;

#else  // #ifndef _H_NONNON_WIN32_OLE_IDROPTARGET

	HDROP hdrop = (HDROP) wparam;
	if ( hdrop == NULL ) { return 0; }


	int count = DragQueryFile( hdrop, 0xffffffff, NULL, 0 );
	int index = 0;
	while( 1 )
	{

		cch += DragQueryFile( hdrop, index, NULL, 0 );

		index++;
		if ( index >= count ) { break; }
	}

	//DragFinish( hdrop );

//n_posix_debug_literal( "%d", cch );

#endif // #ifndef _H_NONNON_WIN32_OLE_IDROPTARGET


	// [!] : "\0\0" termination

	return cch + 2;
}

#define n_win_dropfiles( hwnd, wparam, path ) n_win_dropfiles_multiple( hwnd, wparam, path, N_PATH_MAX ) 

#define n_win_dropfiles_multiple(      hwnd, wparam, path, cch ) n_win_dropfiles_multiple_internal( hwnd, wparam, path, cch,  true ) 
#define n_win_dropfiles_multiple_fast( hwnd, wparam, path, cch ) n_win_dropfiles_multiple_internal( hwnd, wparam, path, cch, false ) 

// internal
void
n_win_dropfiles_multiple_internal( HWND hwnd, WPARAM wparam, n_posix_char *path, size_t path_cch, bool zeroclear )
{

	if ( zeroclear ) { n_string_zero( path, path_cch ); }


#ifdef _H_NONNON_WIN32_OLE_IDROPTARGET

//n_posix_debug_literal( "IDropTarget() : ON" );

	n_IDropTarget_path_get( path, path_cch );

//n_posix_debug_literal( "%s", path );

#else  // #ifndef _H_NONNON_WIN32_OLE_IDROPTARGET

//n_posix_debug_literal( "IDropTarget() : OFF" );


	// [!] : Win98 : fault when execute twice or more


	HDROP hdrop = (HDROP) wparam;
	if ( hdrop == NULL ) { return; }


	size_t count = DragQueryFile( hdrop, 0xffffffff, NULL, 0 );
	size_t index = 0;
	size_t i     = 0;
	while( 1 )
	{

		DragQueryFile( hdrop, index, &path[ i ], path_cch - i );
//n_posix_debug_literal( "%s", &path[ i ] );

		i += DragQueryFile( hdrop, index, NULL, 0 ) + 1;
		n_string_path_terminate( path, i - 1 );

		if ( i >= path_cch ) { n_string_path_terminate( path, 0 ); break; }

		index++;
		if ( index >= count ) { break; }
	}

	DragFinish( hdrop );


#endif // #ifndef _H_NONNON_WIN32_OLE_IDROPTARGET


	// [!] : Win9x : move under other windows

	SetForegroundWindow( hwnd );


	return;
}

n_posix_char*
n_win_dropfiles_multiple_new( HWND hwnd, WPARAM wparam )
{

	// [!] : you need to n_string_path_free() a returned variable

	size_t        cch = n_win_dropfiles_multiple_cch( hwnd, wparam );
	n_posix_char *ret = n_string_path_new_fast( cch );


	n_win_dropfiles_multiple_fast( hwnd, wparam, ret, cch );


	return ret;
}

#define n_win_exec(         a, b ) n_win_execute( a, b, false )
#define n_win_exec_literal( a, b ) n_win_exec( n_posix_literal( a ), b )

void
n_win_execute( n_posix_char *command, WORD showwindow, bool wait )
{

//n_posix_debug( command );


	// [!] : WinExec() hasn't unicode version


	// [Needed] : PROCESS_INFORMATION

	STARTUPINFO         si; ZeroMemory( &si, sizeof( STARTUPINFO         ) );
	PROCESS_INFORMATION pi; ZeroMemory( &pi, sizeof( PROCESS_INFORMATION ) );


	si.cb          = sizeof( STARTUPINFO );
	si.wShowWindow = showwindow;
	si.dwFlags     = STARTF_USESHOWWINDOW;


	{

		// [MSDN] : CreateProcessW() touches the parameter

		n_posix_char *s = n_string_carboncopy( command );

		CreateProcess
		(
			NULL,
			s,
			NULL,NULL,
			false,
			NORMAL_PRIORITY_CLASS,
			NULL,
			NULL,
			&si, &pi
		);

		n_memory_free( s );

	}


	if ( wait ) { WaitForSingleObject( pi.hProcess, INFINITE ); }


	CloseHandle( pi.hThread  );
	CloseHandle( pi.hProcess );


	return;
}


#endif // _H_NONNON_WIN32_WIN_COMMANDLINE

