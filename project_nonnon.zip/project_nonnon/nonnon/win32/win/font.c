// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_FONT
#define _H_NONNON_WIN32_WIN_FONT




#include "./_debug.c"
#include "./message.c"




#define n_win_font_exit( hfont ) DeleteObject( hfont )

#define n_win_font_set( h, hfont, redraw )         n_win_message_send( h, WM_SETFONT, hfont, redraw )
#define n_win_font_get( h                ) (HFONT) n_win_message_send( h, WM_GETFONT,     0,      0 )

#define n_win_font_default( h, redraw ) n_win_font_set( h, GetStockObject( DEFAULT_GUI_FONT ), redraw )




#define n_win_font_logfont2hfont( ptr_lf ) CreateFontIndirect( ptr_lf )

LOGFONT
n_win_font_hfont2logfont( HFONT hfont )
{

	LOGFONT lf; ZeroMemory( &lf, sizeof( LOGFONT ) );

	GetObject( hfont, sizeof( LOGFONT ), &lf );

	return lf;
}

LOGFONT
n_win_font_hwnd2logfont( HWND hwnd )
{

	HFONT   hf = n_win_font_get( hwnd );
	LOGFONT lf = n_win_font_hfont2logfont( hf );

	// [!] : don't touch this

	//n_win_font_exit( hf );

	return lf;
}

int
n_win_font_size_default( HWND hwnd )
{

	int              cb = sizeof( NONCLIENTMETRICS );
	NONCLIENTMETRICS ncm; ZeroMemory( &ncm, cb );

	ncm.cbSize = cb;
	SystemParametersInfo( SPI_GETNONCLIENTMETRICS, cb, &ncm, 0 );


	return ncm.lfCaptionFont.lfHeight;
}

// internal
int CALLBACK
n_win_font_name2hfont_enumfontsproc( const LOGFONT *lf, const TEXTMETRIC *tm, u32 type, LPARAM lparam )
{

	LOGFONT *lf_ret = (LOGFONT*) lparam;


	if ( n_string_is_same( lf->lfFaceName, lf_ret->lfFaceName ) )
	{

		n_memory_copy( lf, lf_ret, sizeof( LOGFONT ) );

		return false;
	}


	return true;
}

HFONT
n_win_font_name2hfont( const n_posix_char *name, s32 size )
{

	LOGFONT lf; ZeroMemory( &lf, sizeof( LOGFONT ) );

	n_string_copy( name, lf.lfFaceName );


	HDC hdc = GetDC( NULL );

	EnumFonts( hdc, NULL, n_win_font_name2hfont_enumfontsproc, (LPARAM) &lf );

	ReleaseDC( NULL, hdc );


	lf.lfWidth  = 0;
	lf.lfHeight = size;


	return n_win_font_logfont2hfont( &lf );
}


#endif // _H_NONNON_WIN32_WIN_FONT

