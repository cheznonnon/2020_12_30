// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_STDSIZE
#define _H_NONNON_WIN32_WIN_STDSIZE




#include "../registry.c"

#include "./font.c"
#include "./gui.c"
#include "./rect.c"
#include "./stdfont.c"
#include "./style.c"




#define n_win_stdsize_icon_large( sx, sy ) n_win_stdsize_icon( sx, sy,  true )
#define n_win_stdsize_icon_small( sx, sy ) n_win_stdsize_icon( sx, sy, false )

void
n_win_stdsize_icon( s32 *sx, s32 *sy, bool is_large )
{

	if ( is_large )
	{
		if ( sx != NULL ) { (*sx) = GetSystemMetrics( SM_CXICON   ); }
		if ( sy != NULL ) { (*sy) = GetSystemMetrics( SM_CYICON   ); }
	} else {
		if ( sx != NULL ) { (*sx) = GetSystemMetrics( SM_CXSMICON ); }
		if ( sy != NULL ) { (*sy) = GetSystemMetrics( SM_CYSMICON ); }
	}


	return;
}

s32
n_win_stdsize_check_radio( HWND hwnd )
{

	s32 ret = 17;

	if ( n_win_style_is_classic() ) { ret = 13; }

	s32    dpi   = n_win_dpi( hwnd );
	double scale = 1.0;

	if ( dpi >  96 )
	{
		ret = 19;
	}

	if ( dpi > 128 )
	{
		scale = (double) dpi / 128;
	}

	return (double) ret * scale;
}

void
n_win_stdsize_text( HWND hwnd, const n_posix_char *str, s32 *sx, s32 *sy )
{

	// [Mechanism]
	//
	//	WM_GETFONT returns real hfont, not copy of it
	//	WM_GETFONT returns NULL when system font
	//	so don't n_win_font_exit() with it


	// [Needed] : multi-thread

	HANDLE hmutex = n_win_mutex_init_and_wait_literal( NULL, "n_win_stdsize_text()" );


	HDC   hdc = GetDC( hwnd );
	HFONT pf  = SelectObject( hdc, n_win_font_get( hwnd ) );

	SIZE size;
	GetTextExtentPoint32( hdc, str, n_posix_strlen( str ), &size );

	SelectObject( hdc, pf );
	ReleaseDC( hwnd, hdc );


	hmutex = n_win_mutex_exit( hmutex );


	if ( sx != NULL ) { (*sx) = size.cx; }
	if ( sy != NULL ) { (*sy) = size.cy; }


	return;
}

int
n_win_stdsize_caret( HWND hwnd )
{

	// [!] : IME uses hard-coded 2px in all version


	// [!] : Win9x/NT4 : "CaretWidth" is not exist and Edit draws a 2px caret

	DWORD caret_size = 2;

	n_posix_char *subkey  = n_posix_literal( "Control Panel\\Desktop" );
	n_posix_char *section = n_posix_literal( "CaretWidth" );

	n_registry_read( HKEY_CURRENT_USER, subkey, section, &caret_size, sizeof( DWORD ) );


	// [!] : Windows doesn't touch when high-DPI settings has high value

	int dpi = n_win_dpi( hwnd );

	if ( ( caret_size == 1 )&&( dpi != 96 ) )
	{
		caret_size *= dpi / 96;
	}


	return caret_size;
}

void
n_win_stdsize( HWND hwnd, s32 *control, s32 *icon, s32 *margin )
{

	// [!] : XP or later only available : SM_CYFOCUSBORDER

	//s32 fx = GetSystemMetrics( SM_CXFOCUSBORDER );
	//s32 fy = GetSystemMetrics( SM_CYFOCUSBORDER );
	s32 mx = GetSystemMetrics( SM_CXEDGE );
	s32 my = GetSystemMetrics( SM_CYEDGE );
	s32 cx = GetSystemMetrics( SM_CXVSCROLL );
	s32 cy = GetSystemMetrics( SM_CYHSCROLL );
	s32 ix = GetSystemMetrics( SM_CXICON );
	s32 iy = GetSystemMetrics( SM_CYICON );

	//s32  b = n_posix_max_s32( bx, by );
	//s32  f = n_posix_max_s32( fx, fy );
	s32  m = n_posix_max_s32( mx, my );
	s32  c = n_posix_max_s32( cx, cy );
	s32  i = n_posix_max_s32( ix, iy );
	s32  s = n_win_dpi( hwnd ) / 96;

/*
	{

		// [!] : use combobox height which is automatically determined

		// [x] : heavy

		HWND h = NULL;
		n_win_gui( hwnd, N_WIN_GUI_COMBO, N_STRING_EMPTY, &h );

		if ( h != NULL )
		{

			n_win_stdfont_init( &h, 1 );

			RECT r = n_win_rect_size( h );

			n_win_stdfont_exit( &h, 1 );

			DestroyWindow( h );

			c = n_posix_max_s32( c, r.bottom );

		}

//n_win_hwndprintf_literal( hwnd, "%d : %d", c, (int) r.bottom );

	}
*/

	{

		// [!] : combobox height equivalent : classic/uxtheme compatible


		// [Needed] : multi-thread

		HANDLE hmutex = n_win_mutex_init_and_wait_literal( NULL, "n_win_stdsize()" );


		HDC   hdc = GetDC( hwnd );
		HFONT pf  = SelectObject( hdc, n_win_stdfont_hfont() );

		SIZE size;
		GetTextExtentPoint32( hdc, N_STRING_SPACE, n_posix_strlen( N_STRING_SPACE ), &size );

		n_win_font_exit( SelectObject( hdc, pf ) );
		ReleaseDC( hwnd, hdc );


		hmutex = n_win_mutex_exit( hmutex );


		s32 ctl = size.cy;

		ctl += GetSystemMetrics( SM_CYEDGE ) * 2 * 2 * s;
 
		c = n_posix_max_s32( c, ctl );

	}

//n_posix_debug_literal( " %d %d ", c, m );

	m = n_posix_max_s32( m, ( c / 8 ) - 1 );
	i = n_posix_max_s32( i, c + ( c / 2 ) );


	// [!] : for alignment : for win_smallbutton.c

	// [!] : backward compatibility : after calculation of "m", "i"

	c += ( c % 2 );


	if ( control != NULL ) { (*control) = c + ( m * 2 ); }
	if ( icon    != NULL ) { (*icon)    = i + ( m * 2 ); }
	if ( margin  != NULL ) { (*margin)  = m            ; }


	return;
}


#endif // _H_NONNON_WIN32_WIN_STDSIZE

