// Nonnon Spider
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/win32/explorer.c"
#include "../nonnon/win32/win_menu.c"




// internal
void
n_spider_menu_rearrange( n_spider *p )
{

	if ( spider.option_suit == 1 )
	{
		n_win_simplemenu_tweak_literal( &spider.simplemenu, 2, 'v' );
		n_win_simplemenu_tweak_literal( &spider.simplemenu, 3, ' ' );
		n_win_simplemenu_tweak_literal( &spider.simplemenu, 4, ' ' );
	} else
	if ( spider.option_suit == 2 )
	{
		n_win_simplemenu_tweak_literal( &spider.simplemenu, 2, ' ' );
		n_win_simplemenu_tweak_literal( &spider.simplemenu, 3, 'v' );
		n_win_simplemenu_tweak_literal( &spider.simplemenu, 4, ' ' );
	} else
	if ( spider.option_suit == 4 )
	{
		n_win_simplemenu_tweak_literal( &spider.simplemenu, 2, ' ' );
		n_win_simplemenu_tweak_literal( &spider.simplemenu, 3, ' ' );
		n_win_simplemenu_tweak_literal( &spider.simplemenu, 4, 'v' );
	}


	return;
}

// internal
void
n_spider_ini_read( n_spider *p )
{

	n_ini ini; n_ini_zero( &ini );
	n_ini_load( &ini, n_project_ini_name );

	spider.option_suit = n_ini_value_int( &ini, p->ini_section, p->ini_lval_suit,  1 );

	n_ini_free( &ini );


	n_spider_menu_rearrange( p );


	return;
}

// internal
void
n_spider_ini_write( n_spider *p )
{

	n_ini ini; n_ini_zero( &ini );
	n_ini_load( &ini, n_project_ini_name );

	n_ini_section_add( &ini, p->ini_section );
	n_ini_key_add_int( &ini, p->ini_section, p->ini_lval_suit, spider.option_suit );

	n_ini_save( &ini, n_project_ini_name );
	n_ini_free( &ini );


	n_explorer_refresh( false );


	return;
}




LRESULT CALLBACK
n_spider_on_event( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		//if ( ( wparam == 0 )||( ( wparam == 67 ) ) )
		{
			SetTimer( hwnd, N_SPIDER_TIMER_ID_STYLE, n_project_settingchange_interval(), NULL );
		}

	break;

	case WM_TIMER :
	{

		if ( wparam != N_SPIDER_TIMER_ID_STYLE ) { break; }

		n_win_timer_exit( hwnd, N_SPIDER_TIMER_ID_STYLE );

		extern void n_spider_style_change( n_spider* );
		n_spider_style_change( &spider );

		extern void n_spider_flush_background( n_spider* );
		n_spider_flush_background( &spider );

		extern void n_spider_redraw( n_spider* );
		n_spider_redraw( &spider );

		n_game_refresh_on();
		n_game_loop();

		n_win_message_send( game.hwnd, WM_PAINT, 0,0 );

	}
	break;


	case WM_DISPLAYCHANGE :
	{

		bool is_maximized = IsZoomed( game.hwnd );
		ShowWindow( game.hwnd, SW_NORMAL );


		extern void n_spider_style_change( n_spider* );
		n_spider_style_change( &spider );


		game.sx = spider.cardgen.csx;
		game.sy = spider.cardgen.csy;

		n_win_set( game.hwnd, NULL, game.sx,game.sy, N_WIN_SET_CENTERING );

		n_game_bmp_init();


		int i = 0;
		while( 1 )
		{

			n_bmp_free( &spider.shadow_bmp_cache[ i ] );

			i++;
			if ( i >= N_SPIDER_SHADOW_COUNT ) { break; }
		}


		extern void n_spider_flush_background( n_spider* );
		n_spider_flush_background( &spider );

		extern void n_spider_reset( n_spider*, bool );
		n_spider_reset( &spider, false );

		extern void n_spider_reposition( n_spider* );
		n_spider_reposition( &spider );

		extern void n_spider_redraw( n_spider* );
		n_spider_redraw( &spider );

		extern void n_spider_pile_draw_all( n_spider* );
		n_spider_pile_draw_all( &spider );


		if ( is_maximized )
		{
			ShowWindow( game.hwnd, SW_MAXIMIZE );
		}


		n_game_refresh_on();
		n_game_loop();

		n_win_message_send( game.hwnd, WM_PAINT, 0,0 );

	}
	break;


	case WM_COMMAND :

		if ( (HWND) lparam == spider.simplemenu.hwnd )
		{

			if ( wparam == -1 )
			{

				n_spider_menu_rearrange( &spider );

			} else
			if ( wparam == 0 )
			{

				n_bmp_flush( &game.bmp, game.color );

				extern void n_spider_replay( n_spider* );
				n_spider_replay( &spider );

				n_game_refresh_resize();

			} else
			if ( wparam == 2 )
			{

				spider.option_suit = 1;

				n_spider_ini_write( &spider );

				extern void n_spider_newgame( n_spider* );
				n_spider_newgame( &spider );

			} else
			if ( wparam == 3 )
			{

				spider.option_suit = 2;

				n_spider_ini_write( &spider );

				extern void n_spider_newgame( n_spider* );
				n_spider_newgame( &spider );

			} else
			if ( wparam == 4 )
			{

				spider.option_suit = 4;

				n_spider_ini_write( &spider );

				extern void n_spider_newgame( n_spider* );
				n_spider_newgame( &spider );

			}// else
		}

	break;


	} // switch()


	n_win_simplemenu_proc( hwnd, msg, &wparam, &lparam, NULL );


	n_win_minsize_proc( hwnd,msg,wparam,lparam, spider.cardgen.csx_min,spider.cardgen.csy_min );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

void
n_spider_menu_init( n_spider *p )
{

	n_win_simplemenu_init( &p->simplemenu );

	n_win_simplemenu_set( &p->simplemenu, 0, NULL, n_posix_literal( "[ ]Replay"   ), NULL );
	n_win_simplemenu_set( &p->simplemenu, 1, NULL, n_posix_literal( "[-]"         ), NULL );
	n_win_simplemenu_set( &p->simplemenu, 2, NULL, n_posix_literal( "[ ]1 Suit"   ), NULL );
	n_win_simplemenu_set( &p->simplemenu, 3, NULL, n_posix_literal( "[ ]2 Suit"   ), NULL );
	n_win_simplemenu_set( &p->simplemenu, 4, NULL, n_posix_literal( "[ ]4 Suit"   ), NULL );


	n_win_titlemenu_init_main( &p->titlemenu, game.hwnd, &p->simplemenu );


	return;
}

LRESULT CALLBACK
n_spider_on_close( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	spider.menu_onoff = false;

	n_win_titlemenu_exit( &spider.titlemenu );

	n_win_simplemenu_exit( &spider.simplemenu );


	return 0;
}

