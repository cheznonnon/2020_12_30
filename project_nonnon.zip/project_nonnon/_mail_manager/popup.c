// Nonnon Mail Manager
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html

// Partial FIle




static HWND             hpopup = NULL;
static n_posix_char *clipboard = NULL;




void
n_mailmanager_popup_resize( HWND hwnd, HWND hedit, bool is_first )
{

	if ( is_first )
	{

		is_first = false;

		s32 desktop_sx, desktop_sy;
		n_win_desktop_size( &desktop_sx, &desktop_sy );

		s32 sx = (double) desktop_sx * 0.4;
		s32 sy = (double) desktop_sy * 0.4;

		n_win_set( hwnd, NULL, sx, sy, N_WIN_SET_CENTERING );

		n_win_move_simple( hedit, 0,0, sx,sy, true );

	} else {

		n_win w;
		n_win_set( hwnd, &w,  -1,  -1, N_WIN_SET_DEFAULT   );

		n_win_move_simple( hedit, 0,0, w.csx,w.csy, true );

	}


	return;
}

LRESULT CALLBACK
n_mailmanager_popup_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static HWND hedit = NULL;


	switch( msg ) {


	case WM_CREATE :


		// Window

		n_win_init_literal( hwnd, "Mail Manager", "A_MAINICON", "" );


		// [x] : you cannot use WS_OVERLAPPEDWINDOW
		//
		//	EnableWindow() will not function

		//n_project_window_resizable( hwnd );


		// [!] : WinXP/Luna : need to set WS_EX_DLGMODALFRAME before WS_*

		n_win_exstyle_new( hwnd, WS_EX_DLGMODALFRAME           );
		n_win_style_new  ( hwnd, N_WS_POPUPWINDOW | WS_SIZEBOX );

		n_win_sysmenu_disable( hwnd, 1,0,0, 1,1, 0, 0 );


		n_win_gui_literal( hwnd, EDITOR, "", &hedit );


		// Size

		n_mailmanager_popup_resize( hwnd, hedit, true );


		// Display

		n_win_text_set( hedit, clipboard );

		ShowWindow( hwnd, SW_NORMAL );

		EnableWindow( GetParent( hwnd ), false );


	break;


	case WM_SIZE :

		n_mailmanager_popup_resize( hwnd, hedit, false );

	break;


	case WM_CLOSE :

		EnableWindow( GetParent( hwnd ), true );
		ShowWindow( hwnd, SW_HIDE );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}


